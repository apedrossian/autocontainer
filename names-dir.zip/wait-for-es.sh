#!/usr/bin/env bash
#   Use this script to test if a given  elastic search host/port are available

cmdname=$(basename $0)

echoerr() { if [[ $QUIET -ne 1 ]]; then echo "$@" 1>&2; fi }

usage()
{
    cat << USAGE >&2
Usage:
    $cmdname host:port 
USAGE
    exit 1
}

set -e

QUIET=0
HOST="$1"
shift
cmd="$@"

start_ts=$(date +%s)
 until curl http://$HOST/_search?q=hello:"elasticsearch!"; do
   echoerr "Elastic Search is unavailable - sleeping"
   sleep 1
done
end_ts=$(date +%s)
echoerr "$cmdname: $HOST is available after $((end_ts - start_ts)) seconds"

echoerr "Elastic Search is up - executing command"
exec $cmd
