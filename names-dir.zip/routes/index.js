var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Names Dir' });
});

/* GET names-dir page. */
router.get('/names-dir', function(req, res, next) {
  res.render('names-dir', { title: 'Names Dir' });
});

/* GET names-dir page. */
router.get('/redis', function(req, res, next) {
  res.render('redis', { title: 'Redis Test', redisKey: '', redisValue: '' });
});


router.post('/redis-key', function(req, res){
  var client = req.client;
  var rkey = req.body.rkey
  var rvalue = req.body.rvalue
  client.set(rkey, rvalue, function(err, reply){
    console.log(reply)
    req.logger.info('Key-Value created on Redis');
  });

  client.get(rkey, function(err, reply){
    res.render('redis',
    {
      title: 'Redis Key Added!',
      redisKey: rkey,
      redisValue: reply
    });
  });
});

router.get('/esearch', function(req, res){
  var esclient = req.esclient;

    res.render('esearch',
    {
      title: 'Elastic Search Query Results!',
    });
});


module.exports = router;
