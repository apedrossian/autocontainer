var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var mlogger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

  //logging info
  var es_host = process.env.ES_HOST;
  var es_port = process.env.ES_PORT;
  var es_connect = es_host + ':' + es_port;
  var bunyan = require('bunyan');
  var elasticsearch = require('bunyan-elasticsearch');
  var esStream = new elasticsearch({
    indexPattern: '[logstash-]YYYY.MM.DD',
    type: 'logs',
    host: es_connect
  });

  esStream.on('info', function(err){
    console.log('Elasticsearch Stream Error:', err.stack);
  });

  var logger = bunyan.createLogger({
    name: "Names-dir App",
    streams: [
      { stream: process.stdout },
      { stream: esStream }
    ],
    serializers: bunyan.stdSerializers
  });

  logger.info('Starting application');
  
  //db info
  var mongo = require('mongodb');
  var monk = require('monk');
  var db_host = process.env.DB_HOST || 'localhost';
  var db_port = process.env.DB_PORT || 27017; 
  var use_db = process.env.USE_DB || 'nameslist'; 
  var connect = db_host + ':' + db_port + '/' + use_db; 
  var db = monk(connect);

  logger.info('Connected to Mongo at %s:%d', db_host, db_port);

  //redis info
  var redis = require('redis');
  var cache_host = process.env.CACHE_HOST || 'localhost';
  var cache_port = process.env.CACHE_PORT || '6379';
  var client = redis.createClient( cache_port , cache_host );
  client.on('connect', function() {
   console.log('Redis Connected');
   logger.info('Connected to Redis at %s:%d', cache_host, cache_port);
  });

//},15000);

//mq info
var amqp = require('amqp');
var amqp_host = process.env.AMQP_HOST || 'localhost';

var routes = require('./routes/index');
var users = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(mlogger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(__dirname + '/public'));

//mq defaults
app.connectionStatus = 'No Server Connection';
app.exchangeStatus = 'No exchange established';
app.queueStatus = 'No queue established';

app.get('/amqp', function(req, res){
  res.render('amqp.jade',
    {
      title: 'Welcome to RabbitMQ and Node/Express',
      connectionStatus: app.connectionStatus,
      exchangeStatus: app.exchangeStatus,
      queueStatus: app.queueStatus
    });
});

app.post('/amqp/start-server', function(req, res){
  app.rabbitMqConnection = amqp.createConnection({ host: amqp_host });
  app.rabbitMqConnection.on('ready', function(){
    app.connectionStatus = 'Connected!';
    logger.info('Connected to Rabbit at %s', amqp_host);
    res.redirect('/amqp');
  });
});

app.post('/amqp/new-exchange', function(req, res){
  app.e = app.rabbitMqConnection.exchange('test-exchange');
  app.exchangeStatus = 'An exchange has been established!';
  logger.info('Exchange created on Rabbit at %s', amqp_host);
  res.redirect('/amqp');
});

app.post('/amqp/new-queue', function(req, res){
  app.q = app.rabbitMqConnection.queue('test-queue');
  app.queueStatus = 'The queue is ready for use!';
  logger.info('Queue created on Rabbit at %s', amqp_host);
  res.redirect('/amqp');
});

app.get('/amqp/message-service', function(req, res){
  app.q.bind(app.e, '#');
  res.render('message-service.jade',
    {
      title: 'Welcome to the messaging service',
      sentMessage: ''
    });
});

app.post('/amqp/newMessage', function(req, res){
  var newMessage = req.body.newMessage;
  app.e.publish('routingKey', { message: newMessage });
  logger.info('Message created on Rabbit queue at %s, message: %s', amqp_host, newMessage );

  app.q.subscribe(function(msg){
    console.log(msg.message);
    res.render('message-service.jade',
    {
      title: 'You\'ve got mail!',
      sentMessage: msg.message
    });
  });
});

// Make our db and redis accessible to our router
app.use(function(req,res,next){
  req.db = db;
  req.client = client;
  req.logger = logger;
  next();
});

app.use('/', routes);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});


// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
